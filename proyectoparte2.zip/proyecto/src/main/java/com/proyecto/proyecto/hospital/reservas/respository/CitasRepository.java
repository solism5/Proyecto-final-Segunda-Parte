package com.proyecto.proyecto.hospital.reservas.respository;

import com.proyecto.proyecto.hospital.reservas.model.Cita;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CitasRepository extends JpaRepository<Cita, String>{
    public Cita findByFecha(String fecha);
}
