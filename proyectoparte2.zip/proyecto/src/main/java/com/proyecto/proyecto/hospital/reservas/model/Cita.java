package com.proyecto.proyecto.hospital.reservas.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;

@Entity
public class Cita {
    @Id
    @NotEmpty
    private String cedula;

    @NotEmpty
    private String fecha;
    @NotEmpty
    private String tipoConsulta; // "UNICA" o "SEGUIMIENTO"
    private String enfermedad;
    private String state;
    
    // Constructor

    public Cita() {
    }

    public Cita(String cedula, String fecha, String tipoConsulta, String enfermedad, String medico, String state) {
        this.cedula = cedula;
        this.fecha = fecha;
        this.tipoConsulta = tipoConsulta;
        this.enfermedad = enfermedad;
        this.state = state;
    }

    // Getters y setters

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTipoConsulta() {
        return tipoConsulta;
    }

    public void setTipoConsulta(String tipoConsulta) {
        this.tipoConsulta = tipoConsulta;
    }

    public String getEnfermedad() {
        return enfermedad;
    }

    public void setEnfermedad(String enfermedad) {
        this.enfermedad = enfermedad;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }


    // Método toString

    @Override

    public String toString() {
        return "Cita{" +
                "cedula='" + cedula + '\'' +
                ", fecha='" + fecha + '\'' +
                ", tipoConsulta='" + tipoConsulta + '\'' +
                ", enfermedad='" + enfermedad + '\'' +
                '}';
    }

}
