package com.proyecto.proyecto.hospital.reservas.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;

@Entity
public class Usuario {
    @Id
    @NotEmpty
    private String cedula;
    
    @NotEmpty
    private String nombre;

    private String email;
    private String password;

    @NotEmpty
    private String direccion;
    @NotEmpty
    private String telefono;

    // Atributo para saber si el usuario es medico o no
    // si es true, es medico, si es false, es paciente
    private boolean admin;

    // Constructor sin argumentos necesario para JPA
    public Usuario() {
    }

    // Constructor con todos los argumentos
    public Usuario(String cedula, String nombre, String email, String password, String direccion, String telefono, boolean admin) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.email = email;
        this.password = password;
        this.direccion = direccion;
        this.telefono = telefono;
        this.admin = admin;
    }

    // Getters y setters
    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    // Método toString
    @Override
    public String toString() {
        return "Usuario{" +
                "cedula='" + cedula + '\'' +
                ", nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", direccion='" + direccion + '\'' +
                ", telefono='" + telefono + '\'' +
                ", admin='" + admin + '\'' +
                '}';
    }
}
