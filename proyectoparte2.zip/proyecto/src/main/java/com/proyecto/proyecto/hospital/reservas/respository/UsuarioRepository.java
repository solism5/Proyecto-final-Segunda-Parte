package com.proyecto.proyecto.hospital.reservas.respository;

import com.proyecto.proyecto.hospital.reservas.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, String> {
    // Método adicional específico para buscar un Usuario por su cédula
    Optional<Usuario> findByCedula(String cedula);

    // Método adicional específico para filtrar un usuario administrador
    Optional<Usuario> findByAdmin(boolean admin);

}
