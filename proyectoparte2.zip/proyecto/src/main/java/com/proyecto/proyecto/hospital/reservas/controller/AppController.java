package com.proyecto.proyecto.hospital.reservas.controller;


import com.proyecto.proyecto.hospital.reservas.model.Usuario;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.proyecto.proyecto.hospital.reservas.model.Fecha;
import com.proyecto.proyecto.hospital.reservas.model.Cita;
import com.proyecto.proyecto.hospital.reservas.respository.CitasRepository;
import com.proyecto.proyecto.hospital.reservas.respository.FechasRepository;
import com.proyecto.proyecto.hospital.reservas.respository.UsuarioRepository;

@Controller
public class AppController {

    boolean loggedIn = false;
    boolean isAdmin = false;
    String cedulaLogged = "";

   // @Autowired
    //private UsuarioRepository usuarioRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private CitasRepository citasRepository;

    @Autowired
    private FechasRepository fechasRepository;


    // General endpoints

    // Mostrar Login
    @GetMapping("/")
    public String mostrarPaginaPrincipal(Model model) {
        Optional<Usuario> usuarioTmp = usuarioRepository.findByCedula("123456789");
        if(!usuarioTmp.isPresent()){
            Usuario firstAdmin = new Usuario();
            firstAdmin.setCedula("123456789");
            firstAdmin.setNombre("admin");
            firstAdmin.setPassword("1234");
            firstAdmin.setAdmin(true);
            firstAdmin.setDireccion("admin");
            firstAdmin.setTelefono("00000000");
            firstAdmin.setEmail("admin@admin.com");
            usuarioRepository.save(firstAdmin);
            System.out.println("\n\n\n\n\n\n\n\nAdmin creado\n\n\n\n\n\n\n\n\n");
        }
        model.addAttribute("usuario", new Usuario());
        return "login";
    }

    // Login Post Endpoint 
    @PostMapping("/")
    public String loginUsuario(@ModelAttribute Usuario usuario) {
        Optional<Usuario> usuarioTmp = usuarioRepository.findByCedula(usuario.getCedula());
        if (usuarioTmp.isPresent()) {
            Usuario usuarioTmp2 = usuarioTmp.get();
            if (usuarioTmp2.getPassword().equals(usuario.getPassword())) {
                isAdmin = usuarioTmp2.isAdmin();
                cedulaLogged = usuarioTmp2.getCedula();
                loggedIn = true;
                return "redirect:/main";
            }
        }
        return "redirect:/";
    }

    // Logout
    @GetMapping("/logout")
    public String logoutUsuario() {
        isAdmin = false;
        cedulaLogged = "";
        return "redirect:/";
    }

    // Mostrar Register
    @GetMapping("/register")
    public String mostrarPaginaRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "register";
    }

    // Register Post Endpoint
    @PostMapping("/register")
    public String registrarUsuario(@ModelAttribute Usuario usuario) {
        // verificar que la cedula no exista
        Optional<Usuario> usuarioTmp = usuarioRepository.findByCedula(usuario.getCedula());
        if (usuarioTmp.isPresent()) {
            return "redirect:/register";
        }
        usuarioRepository.save(usuario);
        return "redirect:/";
    }

    // Main Page
    @GetMapping("/main")
    public String mostrarPaginaLogin() {
        if(loggedIn){
            // System.out.println("\n\n\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            // System.out.println("is admin");
            // System.out.println(isAdmin);
            // System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n\n\n");
            if (isAdmin) return "main-page-admin";
            return "main-page-user";
        }else{
            return "redirect:/";
        }
        
    }

    // =============== Citas Endpoints ===============
    // Agregar Cita
    @GetMapping("/citas/agregar")
    public String mostrarAddCita(Model model) {
        if(loggedIn){
            model.addAttribute("fechas", fechasRepository.findAll());
            model.addAttribute("pacientes", usuarioRepository.findAll());
            model.addAttribute("medicos", usuarioRepository.findAll());
            model.addAttribute("cita", new Cita());
            return "agregar-cita";
        }else{
            return "redirect:/";
        }
        
    }

    // Agregar Cita Post Endpoint
    @PostMapping("/citas/agregar")
    public String addCita(@ModelAttribute Cita cita) {
        citasRepository.save(cita);
        return "redirect:/citas/agregar";
    }

    // Agregar Fecha
    @GetMapping("/citas/agregar/fechas")
    public String mostrarAddFechas(Model model) {
        if(loggedIn){
            model.addAttribute("fechaTmp", new Fecha());
            model.addAttribute("medicos", usuarioRepository.findAll());
            return "agregar-fecha";
        }else{
            return "redirect:/";
        }
        
    }

    // Agregar Fecha Post Endpoint
    @PostMapping("/citas/agregar/fechas")
    public String addFechas(@ModelAttribute Fecha fechaTmp) {
        fechasRepository.save(fechaTmp);
        return "redirect:/citas/agregar/fechas";
    }

    // Listar Citas
    @GetMapping("/citas/listar")
    public String getCitas(Model model) {
        if(loggedIn){
            model.addAttribute("citas", citasRepository.findAll());
            return "lista-citas-admin";
        }else{
            return "redirect:/";
        }
    }

    // Listar Citas paciente
    @GetMapping("/citas/listar/paciente")
    public String getCitasEspecificas(Model model) {
        if(loggedIn){
            List<Cita> citas = citasRepository.findAll();
            // filtrar las citas que sean del usuario loggeado y guardarlas en una lista llamada citasFiltradas
            List<Cita> citasFiltradas = citas;
            
            for (Cita cita : citas) {
                if (!cita.getCedula().equals(cedulaLogged)) {
                    citasFiltradas.remove(cita);
                }
            }
            model.addAttribute("citas", citasFiltradas);
            return "lista-citas-user";
        }else{
            return "redirect:/";
        }
    }

    // Eliminar Cita que recibe el id de la cita a eliminar por el link
    @PostMapping("/citas/eliminar/{id}/{fecha}")
    public String eliminarCita(@PathVariable String id, @PathVariable String fecha) {
        if(loggedIn){
            List<Cita> citas = citasRepository.findAll();
            for (Cita cita : citas) {
                if (cita.getCedula().equals(id) && cita.getFecha().equals(fecha)) {
                    citasRepository.delete(cita);
                }
            }
            return "redirect:/citas/listar/paciente";
        }else{
            return "redirect:/";
        }
    }
    // ================== Usuarios Endpoints ==================
    // Agregar Usuario
    @GetMapping("/usuarios/agregar")
    public String mostrarFormularioAgregarUsuario(Model model) {
        if(loggedIn){
            model.addAttribute("usuario", new Usuario());
            return "agregar-usuario";
        }else{
            return "redirect:/";
        }
    }

    // Agregar Usuario Post Endpoint
    @PostMapping("/usuarios/agregar")
    public String agregarUsuario(@ModelAttribute Usuario usuario) {
        // verificar que la cedula no exista
        Optional<Usuario> usuarioTmp = usuarioRepository.findByCedula(usuario.getCedula());
        if (usuarioTmp.isPresent()) {
            return "redirect:/usuarios/agregar";
        }
        usuarioRepository.save(usuario);
        return "redirect:/usuarios/agregar";
    }

    // Listar Usuarios
    @GetMapping("/usuarios/listar")
    public String listarUsuarios(Model model) {
        if(loggedIn){
            model.addAttribute("usuarios", usuarioRepository.findAll());
            return "lista-usuarios";
        }else{
            return "redirect:/";
        }
    }

    // Listar Pacientes
    @GetMapping("/usuarios/listar/pacientes")
    public String listarPacientes(Model model) {
        if(loggedIn){
            model.addAttribute("usuarios", usuarioRepository.findAll());
            return "lista-pacientes";
        }else{
            return "redirect:/";
        }
    }

    // Listar Medicos
    @GetMapping("/usuarios/listar/medicos")
    public String listarMedicos(Model model) {
        if(loggedIn){
            model.addAttribute("usuarios", usuarioRepository.findAll());
            return "lista-medicos";
        }else{
            return "redirect:/";
        }
    }

    // Mostrar Actualizar Usuario
    @GetMapping("/perfil/modificar")
    public String mostrarActualizarUsuario(Model model) {
        if(loggedIn){
            // encontrar el usuario con la cedula loggeada
            Optional<Usuario> usuarioTmp = usuarioRepository.findByCedula(cedulaLogged);
            model.addAttribute("usuario", usuarioTmp.get());
            return "modificar-perfil";
        }else{
            return "redirect:/";
        }
    }

    // Actualizar Usuario put Endpoint
    @PostMapping("/usuarios/actualizar")
    public String actualizarUsuario(@ModelAttribute Usuario usuario) {
        if(loggedIn){
            System.out.println("\n\n\n\n\n Cedula: " + usuario.getCedula() + "\n\n\n\n\n");
            Optional<Usuario> usuarioTmp = usuarioRepository.findByCedula(usuario.getCedula());
            if (usuarioTmp.isPresent()) {
                Usuario usuarioTmp2 = usuarioTmp.get();
                usuarioTmp2.setNombre(usuario.getNombre());
                usuarioTmp2.setEmail(usuario.getEmail());
                usuarioTmp2.setPassword(usuario.getPassword());
                usuarioTmp2.setDireccion(usuario.getDireccion());
                usuarioTmp2.setTelefono(usuario.getTelefono());
                usuarioRepository.save(usuarioTmp2);
            }
            return "redirect:/main";
        }else{
            return "redirect:/";
        }
    }
}
