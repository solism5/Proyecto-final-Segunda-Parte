package com.proyecto.proyecto.hospital.reservas.model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;

@Entity
public class Fecha {
    @Id
    @NotEmpty
    private String fecha;

    @NotEmpty 
    private String medico;

    
    public Fecha() {
    }

    public Fecha(String fecha) {
        this.fecha = fecha;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getMedico() {
        return medico;
    }

    public void setMedico(String medico) {
        this.medico = medico;
    }


    // toString method
    @Override
    public String toString() {
        return "Fecha{" +
                "fecha='" + fecha + '\'' +
                '}';
    }
    
    
}
