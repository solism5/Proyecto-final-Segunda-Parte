package com.proyecto.proyecto.hospital.reservas.respository;

import com.proyecto.proyecto.hospital.reservas.model.Fecha;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FechasRepository extends JpaRepository<Fecha, String>{
    
}